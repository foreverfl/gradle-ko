plugins {
    `cpp-library` // <1>
    `cpp-unit-test` // <2>
}

library {
    targetMachines.add(machines.windows.x86_64) // <3>
}
