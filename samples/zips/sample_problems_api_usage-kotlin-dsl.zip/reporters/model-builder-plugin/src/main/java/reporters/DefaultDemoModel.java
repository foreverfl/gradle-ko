package reporters;

public class DefaultDemoModel implements DemoModel {
}
