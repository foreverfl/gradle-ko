rootProject.name = "jvm-multi-project-with-test-aggregation-distribution"

// production code projects
include("application", "list", "utilities")
