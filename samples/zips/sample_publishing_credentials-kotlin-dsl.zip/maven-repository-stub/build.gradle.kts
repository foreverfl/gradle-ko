plugins {
    `kotlin-dsl`
}

repositories {
    mavenCentral()
}

dependencies {
    implementation("com.github.tomakehurst:wiremock:2.26.3")
}
