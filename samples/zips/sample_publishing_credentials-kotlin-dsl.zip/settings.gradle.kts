rootProject.name = "sample"

includeBuild("maven-repository-stub")
