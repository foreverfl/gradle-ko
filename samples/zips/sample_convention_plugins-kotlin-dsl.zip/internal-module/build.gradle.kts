plugins {
    id("myproject.java-conventions")
}

dependencies {
    // internal module dependencies
}
