## API
public API description for library b

## Changelog
- change 1
- change 2
