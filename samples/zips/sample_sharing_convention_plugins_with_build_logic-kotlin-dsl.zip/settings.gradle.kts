rootProject.name = "sample"
includeBuild("build-conventions")
include("application", "utilities", "list")
