plugins {
    id("myproject.java-conventions")
    id("java-library")
}

dependencies {
    api(project(":list"))
}
