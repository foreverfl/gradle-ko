tasks.register<com.example.GreetingTask>("greet") {
    greeting = "Hello from 'myproject.greeting' plugin"
}
