package com.example.myproduct.model

data class MyProductRelease(
        val version: String,
        val releaseNotes: String
)
