plugins {
    id("buildlogic.groovy-common-conventions") // <1>
    `java-library` // <2>
}
