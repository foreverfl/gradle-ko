plugins {
    groovy // <1>
}

repositories {
    mavenCentral() // <2>
}

dependencies {
    constraints {
        implementation("org.apache.commons:commons-text:1.12.0") // <3>

        implementation("org.codehaus.groovy:groovy-all:3.0.22")
    }

    implementation("org.codehaus.groovy:groovy-all") // <4>

    testImplementation("org.junit.jupiter:junit-jupiter:5.10.3") // <5>

    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

tasks.named<Test>("test") {
    useJUnitPlatform() // <6>
}
