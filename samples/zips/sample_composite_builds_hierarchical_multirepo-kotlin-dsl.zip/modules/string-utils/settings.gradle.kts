rootProject.name = "string-utils"
