rootProject.name = "dependency-reports"
