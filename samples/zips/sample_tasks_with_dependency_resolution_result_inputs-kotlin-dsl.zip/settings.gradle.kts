rootProject.name = "tasks-with-dependency-resolution-result-inputs"
includeBuild("dependency-reports")

include("utilities")
include("list")

dependencyResolutionManagement {
    repositories {
        mavenCentral()
    }
}
