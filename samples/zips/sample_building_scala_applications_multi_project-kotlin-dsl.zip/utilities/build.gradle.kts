plugins {
    id("buildlogic.scala-library-conventions")
}

dependencies {
    api(project(":list"))
}
