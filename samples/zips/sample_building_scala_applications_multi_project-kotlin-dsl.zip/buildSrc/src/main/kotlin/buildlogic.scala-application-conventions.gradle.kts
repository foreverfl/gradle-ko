plugins {
    id("buildlogic.scala-common-conventions") // <1>
    application // <2>
}
