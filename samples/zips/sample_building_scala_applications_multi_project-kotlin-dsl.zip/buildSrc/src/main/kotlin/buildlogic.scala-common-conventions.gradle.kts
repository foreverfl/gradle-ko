plugins {
    scala // <1>
}

repositories {
    mavenCentral() // <2>
}

dependencies {
    constraints {
        implementation("org.apache.commons:commons-text:1.12.0") // <3>

        implementation("org.scala-lang:scala-library:2.13.14")
    }

    implementation("org.scala-lang:scala-library") // <4>

    testImplementation("org.junit.jupiter:junit-jupiter:5.10.3") // <5>

    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

tasks.named<Test>("test") {
    useJUnitPlatform() // <6>
}
