plugins {
    id("buildlogic.scala-common-conventions") // <1>
    `java-library` // <2>
}
