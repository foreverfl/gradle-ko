plugins {
    `cpp-application` // <1>
    `cpp-unit-test` // <2>
}

application { // <3>
    targetMachines.add(machines.windows.x86_64)
}
